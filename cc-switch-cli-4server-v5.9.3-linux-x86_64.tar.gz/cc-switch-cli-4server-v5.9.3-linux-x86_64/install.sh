#!/usr/bin/env bash
set -Eeuo pipefail

BIN_NAME="cc-switch"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_BIN="${SCRIPT_DIR}/${BIN_NAME}"
VERSION_FILE="${SCRIPT_DIR}/VERSION"
ARCH_FILE="${SCRIPT_DIR}/ARCH"
CHECKSUM_FILE="${SCRIPT_DIR}/SHA256SUMS"
INSTALL_DIR="${CC_SWITCH_INSTALL_DIR:-${HOME}/.local/bin}"
TARGET="${INSTALL_DIR}/${BIN_NAME}"
FORCE_OVERWRITE="${CC_SWITCH_FORCE:-0}"
STAGED_TARGET=""

info() { printf '  \033[1;32minfo\033[0m: %s\n' "$*"; }
warn() { printf '  \033[1;33mwarn\033[0m: %s\n' "$*" >&2; }
err()  { printf '  \033[1;31merror\033[0m: %s\n' "$*" >&2; }

cleanup() {
  if [[ -n "${STAGED_TARGET}" && -f "${STAGED_TARGET}" ]]; then
    rm -f -- "${STAGED_TARGET}"
  fi
}

on_error() {
  err "Installation failed (line ${1:-?})."
}

need_file() {
  if [[ ! -f "$1" ]]; then
    err "Offline package is incomplete; missing: $(basename -- "$1")"
    exit 1
  fi
}

normalize_arch() {
  case "$1" in
    x86_64|amd64) printf 'x86_64' ;;
    aarch64|arm64) printf 'aarch64' ;;
    *) printf '%s' "$1" ;;
  esac
}

check_platform() {
  local os actual_arch package_arch
  os="$(uname -s 2>/dev/null || true)"
  actual_arch="$(normalize_arch "$(uname -m 2>/dev/null || true)")"
  package_arch="$(normalize_arch "$(tr -d '[:space:]' < "${ARCH_FILE}")")"

  if [[ "${os}" != "Linux" ]]; then
    err "This offline package only supports Linux (detected: ${os:-unknown})."
    exit 1
  fi

  if [[ "${actual_arch}" != "${package_arch}" ]]; then
    err "Package architecture is ${package_arch}, but this server is ${actual_arch}."
    err "Download the matching server package and try again."
    exit 1
  fi
}

verify_payload() {
  local expected actual
  expected="$(awk '$2 == "cc-switch" || $2 == "*cc-switch" { print $1; exit }' "${CHECKSUM_FILE}")"

  if [[ -z "${expected}" ]]; then
    err "SHA256SUMS does not contain an entry for ${BIN_NAME}."
    exit 1
  fi

  if command -v sha256sum >/dev/null 2>&1; then
    actual="$(sha256sum "${SOURCE_BIN}" | awk '{print $1}')"
  elif command -v shasum >/dev/null 2>&1; then
    actual="$(shasum -a 256 "${SOURCE_BIN}" | awk '{print $1}')"
  else
    err "Neither sha256sum nor shasum is available; cannot verify the offline payload."
    exit 1
  fi

  if [[ "${actual}" != "${expected}" ]]; then
    err "Checksum verification failed for ${BIN_NAME}."
    err "The package may be incomplete or corrupted; do not install it."
    exit 1
  fi

  info "Payload checksum verified."
}

installed_version() {
  local candidate="${1:-}"
  if [[ -n "${candidate}" && -x "${candidate}" ]]; then
    "${candidate}" --version 2>/dev/null | head -n 1 || true
  fi
}

confirm_overwrite_if_needed() {
  local current_version reply

  if [[ ! -e "${TARGET}" ]]; then
    return 0
  fi

  current_version="$(installed_version "${TARGET}")"
  if [[ "${FORCE_OVERWRITE}" == "1" ]]; then
    warn "Existing installation detected at ${TARGET}${current_version:+ (${current_version})}; overwriting because CC_SWITCH_FORCE=1."
    return 0
  fi

  if ! exec 3<> /dev/tty 2>/dev/null; then
    err "Existing installation detected at ${TARGET}${current_version:+ (${current_version})}."
    err "Nothing was overwritten. Run interactively, or set CC_SWITCH_FORCE=1."
    exit 1
  fi

  printf '  Existing installation detected at %s' "${TARGET}" >&3
  if [[ -n "${current_version}" ]]; then
    printf ' (%s)' "${current_version}" >&3
  fi
  printf '.\n\n  [U]pdate or [C]ancel? [U/c] ' >&3
  IFS= read -r reply <&3
  exec 3>&-

  case "${reply:-u}" in
    u|U|update|UPDATE|"") return 0 ;;
    c|C|cancel|CANCEL)
      info "Installation canceled."
      exit 0
      ;;
    *)
      err "Unrecognized choice: ${reply}"
      exit 1
      ;;
  esac
}

install_binary() {
  mkdir -p -- "${INSTALL_DIR}"
  STAGED_TARGET="${TARGET}.new.$$"
  cp -- "${SOURCE_BIN}" "${STAGED_TARGET}"
  chmod 755 "${STAGED_TARGET}"
  mv -f -- "${STAGED_TARGET}" "${TARGET}"
  STAGED_TARGET=""
}

check_path() {
  local resolved shell_name profile command_hint
  resolved="$(command -v "${BIN_NAME}" 2>/dev/null || true)"
  if [[ -n "${resolved}" && "${resolved}" != "${TARGET}" ]]; then
    warn "${BIN_NAME} currently resolves to ${resolved}; ${TARGET} may be shadowed."
  fi

  case ":${PATH}:" in
    *":${INSTALL_DIR}:"*) return 0 ;;
  esac

  shell_name="$(basename "${SHELL:-bash}")"
  case "${shell_name}" in
    zsh)
      profile='$HOME/.zshrc'
      command_hint="export PATH=\"${INSTALL_DIR}:\$PATH\""
      ;;
    fish)
      profile='$HOME/.config/fish/config.fish'
      command_hint="fish_add_path ${INSTALL_DIR}"
      ;;
    *)
      profile='$HOME/.bashrc'
      command_hint="export PATH=\"${INSTALL_DIR}:\$PATH\""
      ;;
  esac

  warn "${INSTALL_DIR} is not in PATH."
  printf '  Add this to %s:\n\n    %s\n\n' "${profile}" "${command_hint}"
}

main() {
  trap cleanup EXIT
  trap 'on_error "${LINENO}"' ERR

  need_file "${SOURCE_BIN}"
  need_file "${VERSION_FILE}"
  need_file "${ARCH_FILE}"
  need_file "${CHECKSUM_FILE}"

  check_platform
  verify_payload
  confirm_overwrite_if_needed
  install_binary

  info "Installed ${BIN_NAME} $(tr -d '[:space:]' < "${VERSION_FILE}") to ${TARGET}."
  check_path
  printf '  Run \033[1m%s --version\033[0m to verify.\n\n' "${TARGET}"
}

main "$@"
